go to secrets type "token" in key then in value your token

Note- Dont include ""